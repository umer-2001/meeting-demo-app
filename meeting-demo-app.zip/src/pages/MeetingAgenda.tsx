import React from "react";

const MeetingAgenda = () => {
  return <div>MeetingAgenda</div>;
};

export default MeetingAgenda;
