import React from "react";

const Anouncement = () => {
  return <div>Anouncement</div>;
};

export default Anouncement;
