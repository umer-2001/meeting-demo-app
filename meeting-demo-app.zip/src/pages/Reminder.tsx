import React from "react";

const Reminder = () => {
  return <div>Reminder</div>;
};

export default Reminder;
